module.exports.load = async function(app, db) {
  app.get("/api", async (req, res) => {
    res.send(
      {
        
      }
    );
  });
};