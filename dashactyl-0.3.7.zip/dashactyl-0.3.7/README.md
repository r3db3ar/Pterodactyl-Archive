![Banner](https://media.discordapp.net/attachments/706970617471303761/768606122147708968/pterodactyl-panel.png)

# Dashactyl

Dashactyl is a professional panel for allowing users to split resources for servers on the Pterodactyl Panel. 

Dashactyl is developed by the community and people. Check out the Discord: https://discord.gg/yEv2KhVbWX

# Wiki

Need to install Dashactyl? Need API documentations? Need a place to find themes?

Check out the wiki! https://github.com/real2two/dashactyl/wiki

# Disclaimer

We are not responsible for any damages.

You should not download anything from the develop branch! These files are not ready for production yet, and will be soon!
